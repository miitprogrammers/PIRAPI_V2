$batchFile = "J:\MIIT2024\softpren\PIRAPI\pirapi.bat"
Start-Process "$batchFile" -Verb RunAs
