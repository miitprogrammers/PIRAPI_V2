const express = require("express");
const https = require("https");
const router = express.Router();

// Endpoint untuk menampilkan gambar dari URL
router.get("/image", (req, res) => {});

module.exports = router;
