const express = require("express");
const fileUpload = require("express-fileupload");
const bodyParser = require("body-parser");
const morgan = require("morgan");
const cors = require("cors");
const app = express();
const PORT = 3001;
const path = require("path");
const frontend = express();
const frontendPORT = process.env.PORT || 3000;
const https = require("https");
const fs = require("fs");

const sslOptions = {
  key: fs.readFileSync(path.join('./cert', 'privkey.pem')),  // Kunci privat
  cert: fs.readFileSync(path.join('./cert', 'cert.pem')),   // Sertifikat utama
  ca: fs.readFileSync(path.join('./cert', 'chain.pem'))     // Sertifikat CA (opsional, jika menggunakan intermediate certificate)
};

const corsOpts = {
  origin: "*",
  methods: ["POST", "GET"],
};

app.use(cors(corsOpts));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(morgan("dev"));

app.use(
  fileUpload({
    createParentPath: true,
  })
);

// Endpoint sederhana
const myapi = require("./controlers/index.js");
app.use("/", myapi);
// Jalankan server
app.listen(PORT, () => {
  console.log(`Server berjalan di http://localhost:${PORT}`);
});

// https.createServer(sslOptions, app).listen(PORT, () => {
//   console.log(`Server berjalan di https://localhost:${PORT}`);
// });

// Sajikan file statis dari folder 'dist'
frontend.use(express.static(path.join(__dirname, "dist")));

// Tangani semua rute dengan mengembalikan file index.html
frontend.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "dist", "index.html"));
});

// Jalankan server
// https.createServer(sslOptions, frontend).listen(frontendPORT, '0.0.0.0', () => {
//   console.log('Server berjalan di https://pirsoftpren.miit-s.com');
// });

// frontend.listen(frontendPORT, () => {
//   console.log('Server berjalan di http://localhost:3000');
// })


