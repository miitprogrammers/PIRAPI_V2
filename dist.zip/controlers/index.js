const express = require("express");
const router = express.Router();

const auth = require("./authControler.js");
const usersettings = require("./userSettings.js");
const setup = require("./setupControler.js");

// authentication
router.post("/auth/login", auth.login);
router.post("/auth/getakundata", auth.getakundata);
router.post("/auth/getsetting", auth.getsetting);
router.post("/auth/getmenus", auth.getmenu);
router.post("/auth/getmenusadmin", auth.getmenuadmin);
router.post("/auth/updateaccess", auth.updateaccess);
router.post("/auth/updatemenuview", auth.updatemenuview);
router.post("/auth/getaccess", auth.reqaccess);

// user settings
router.post("/usersetting/newrole", usersettings.newRole);
router.post("/usersetting/getroles", usersettings.getroles);
router.post("/usersetting/editrole", usersettings.editRole);
router.post("/usersetting/deleterole", usersettings.deleteRole);
router.post("/usersetting/newuser", usersettings.newUser);
router.post("/usersetting/users", usersettings.users);
router.post("/usersetting/getuserdata", usersettings.getuserdata);
router.post("/usersetting/edituserdata", usersettings.edituserdata);
router.post("/usersetting/changesign", usersettings.changeSign);
router.post("/usersetting/editpassword", usersettings.changePassAdminSide);
router.post("/usersetting/deleteuser", usersettings.deleteUser);

// setups
router.post("/setup/newmethod", setup.newmethod);
router.post("/setup/getmethods", setup.getMethod);
router.post("/setup/updatemethod", setup.updatemethod);
router.post("/setup/deletemethod", setup.deletMethod);
router.post("/setup/addtool", setup.addTool);
router.post("/setup/gettools", setup.getTools);

module.exports = router;
