const crypter = require("../helpers/crypter");
const Crud = require("../model/crud.js");

module.exports = {
  newmethod: async (req, res) => {
    try {
      const db = new Crud();
      const hash = req.body.hash;
      const obj = crypter.decryptObject(hash);
      await checkMethod(obj.methodName);
      await db.insert("t_method", obj);
      return res.status(200).json({obj});
    } catch (error) {
      return res.status(404).json({error});
    }
  },
  updatemethod: async (req, res) => {
    try {
      const db = new Crud();
      const hash = req.body.hash;
      const obj = crypter.decryptObject(hash);
      await checkMethod(obj.methodName);
      db.where("id=", obj.id);
      await db.update("t_method", obj);
      return res.status(200).json({obj});
    } catch (error) {
      return res.status(404).json({error});
    }
  },
  getMethod: async (req, res) => {
    try {
      const db = new Crud();
      db.select("*");
      db.where("active=", 1);
      const methods = await db.get("t_method");

      return res.status(200).json({methods});
    } catch (error) {
      return res.status(404).json({error});
    }
  },
  deletMethod: async (req, res) => {
    try {
      const db = new Crud();
      const hash = req.body.hash;
      const obj = crypter.decryptObject(hash);
      db.where("id=", obj.deleteId);
      await db.update("t_method", {active: 0});
      return res.status(200).json({obj});
    } catch (error) {
      return res.status(404).json({error});
    }
  },
  getTools: async (req, res) => {
    try {
      const db = new Crud();
      db.select("*");
      db.join("left", "t_method", "t_tool.method", "t_method.id");
      db.where("t_tool.active=", 1);
      const tools = await db.get("t_tool");

      return res.status(200).json({tools});
    } catch (error) {
      return res.status(404).json({error});
    }
  },

  addTool: async (req, res) => {
    try {
      const db = new Crud();
      const hash = req.body.hash;
      const obj = crypter.decryptObject(hash);
      await checkTool(obj.toolName);
      const response = await db.insert("t_tool", obj);
      return res.status(200).json({obj});
    } catch (error) {
      return res.status(404).json({error});
    }
  },
};

const checkMethod = (methodName) => {
  return new Promise(async (resolve, reject) => {
    try {
      const dataBase = new Crud();
      dataBase.select("*");
      dataBase.where("methodName=", methodName);
      dataBase.where("active=", 1);

      const res = await dataBase.get("t_method");
      if (res.length > 0) {
        reject("Method name is already taken");
      } else {
        resolve(res);
      }
    } catch (error) {
      reject(error);
    }
  });
};

const checkTool = (toolName) => {
  return new Promise(async (resolve, reject) => {
    try {
      const dataBase = new Crud();
      dataBase.select("*");
      dataBase.where("toolName=", toolName);
      dataBase.where("active=", 1);

      const res = await dataBase.get("t_tool");
      if (res.length > 0) {
        reject("Tool name is already taken");
      } else {
        resolve(res);
      }
    } catch (error) {
      reject(error);
    }
  });
};
